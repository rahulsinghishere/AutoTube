from moviepy.editor import *
import random
import os

dir_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

def GetDaySuffix(day):
    if day == 1 or day == 21 or day == 31:
        return "st"
    elif day == 2 or day == 22:
        return "nd"
    elif day == 3 or day == 23:
        return "rd"
    else:
        return "th"

dir_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
music_path = os.path.join(dir_path, "Music/")
#output_path = os.path.join(dir_path, "Output/")

def add_return_comment(comment):
    need_return = 30
    new_comment = ""
    return_added = 0
    return_added += comment.count('\n')
    for i, letter in enumerate(comment):
        if i > need_return and letter == " ":
            letter = "\n"
            need_return += 30
            return_added += 1
        new_comment += letter
    return new_comment, return_added
        

class CreateMovie():

    @classmethod
    def CreateMP4(cls, post_data):
        #print(f"{post_data} data")
        clips = []
        for post in post_data:
            outputvideopath = os.path.dirname(post['image_path'])
            print(outputvideopath)
            videofilename = os.path.join(outputvideopath,f"video_{post["id"]}.mp4") 
            music_file = os.path.join(music_path, f"music{random.randint(0,4)}.mp3")
            audio = AudioFileClip(music_file)
            if "gif" not in post['image_path']:
                clip = ImageSequenceClip([post['image_path']], durations=[12])
                clip.audio = audio.subclip(0,clip.duration)
                clip.write_videofile(videofilename, fps = 24)
            else:
                clip = VideoFileClip(post['image_path'])
                clip.audio = audio.subclip(0,clip.duration)
                clip.write_videofile(videofilename, fps = 24)

